
  # Student Competition Platform

  This is a code bundle for Student Competition Platform. The original project is available at https://www.figma.com/design/vfhDJWFMJGYpkaRmDkrygF/Student-Competition-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  